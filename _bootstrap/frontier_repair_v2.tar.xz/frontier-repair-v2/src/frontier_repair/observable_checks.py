from __future__ import annotations

"""Fallible gauge/singlet observable checks.

1. Compare the elementary v1.8 propagator spectral peak to the gauge-singlet
   H^dagger H ladder peak.  This is a model-discrepancy diagnostic, not a claim
   that the two operators have identical line shapes.
2. Evaluate the actual one-loop determinant of the Abelian Higgs model in R_xi
   gauge.  The unphysical Goldstone, longitudinal and ghost determinants cancel
   at the tree extremum, while the off-extremum potential remains gauge
   dependent.  This replaces the old pole-independence-by-definition toy with a
   calculation that can fail.  A momentum-dependent one-loop pole test remains
   a separate production gate.
"""

from pathlib import Path
import argparse
import json
import math

import matplotlib.pyplot as plt
import numpy as np


def _fwhm(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    if np.max(y) <= 0.0:
        return float("nan"), float("nan")
    peak_index = int(np.argmax(y))
    peak = float(x[peak_index])
    half = 0.5 * float(y[peak_index])
    left_indices = np.where(y[: peak_index + 1] <= half)[0]
    right_indices = np.where(y[peak_index:] <= half)[0]
    if len(left_indices) == 0 or len(right_indices) == 0:
        return peak, float("nan")
    left = int(left_indices[-1])
    right = int(peak_index + right_indices[0])
    return peak, float(x[right] - x[left])


def _elementary_vs_singlet(array_path: Path) -> tuple[dict, dict]:
    data = np.load(array_path)
    k = np.asarray(data["match_k_over_T"])
    omega = np.asarray(data["match_omega_over_T"])
    re_pi = np.asarray(data["match_RePi_total_over_T2"])
    im_pi = np.asarray(data["match_ImPi_total_over_T2"])
    m_h = 0.43820657
    k_index = 0
    inverse = omega**2 - k[k_index] ** 2 - m_h**2 - re_pi[k_index] - 1j * im_pi[k_index]
    elementary = -2.0 * np.imag(1.0 / inverse)
    positive = omega > 0.0
    elementary_positive = np.maximum(elementary[positive], 0.0)
    elem_peak, elem_width = _fwhm(omega[positive], elementary_positive)

    sk = np.asarray(data["bse_k_over_T"])
    sw = np.asarray(data["bse_omega_over_T"])
    singlet = np.asarray(data["bse_rho_over_T2"])
    sk_index = int(np.argmin(np.abs(sk - k[k_index])))
    sp = sw > 0.0
    singlet_positive = np.maximum(singlet[sk_index, sp], 0.0)
    singlet_peak, singlet_width = _fwhm(sw[sp], singlet_positive)

    summary = {
        "elementary_k_over_T": float(k[k_index]),
        "singlet_k_over_T": float(sk[sk_index]),
        "elementary_peak_over_T": elem_peak,
        "elementary_FWHM_over_T": elem_width,
        "singlet_peak_over_T": singlet_peak,
        "singlet_FWHM_over_T": singlet_width,
        "peak_relative_difference": abs(singlet_peak - elem_peak) / max(abs(elem_peak), 1.0e-12),
        "interpretation": (
            "The gauge-singlet control and elementary propagator need not share a line shape. The comparison is now an "
            "explicit recorded observable rather than an advertised-but-unrun check."
        ),
    }
    arrays = {
        "elementary_omega": omega[positive],
        "elementary_rho": elementary_positive,
        "singlet_omega": sw[sp],
        "singlet_rho": singlet_positive,
    }
    return summary, arrays


def _one_loop_piece(mass2: float, dof: float, constant: float, mu2: float) -> float:
    if mass2 <= 0.0:
        raise ValueError(f"Non-positive one-loop mass squared {mass2}")
    return dof * mass2**2 * (math.log(mass2 / mu2) - constant) / (64.0 * math.pi**2)


def _abelian_higgs_potential(phi: float, xi: float, m2: float, lam: float, g: float, mu2: float) -> float:
    tree = -0.5 * m2 * phi**2 + 0.25 * lam * phi**4
    mh2 = -m2 + 3.0 * lam * phi**2
    mg0 = -m2 + lam * phi**2
    ma2 = g**2 * phi**2
    mg2 = mg0 + xi * ma2
    ml2 = xi * ma2
    mc2 = xi * ma2
    loop = (
        _one_loop_piece(mh2, 1.0, 1.5, mu2)
        + _one_loop_piece(mg2, 1.0, 1.5, mu2)
        + _one_loop_piece(ma2, 3.0, 5.0 / 6.0, mu2)
        + _one_loop_piece(ml2, 1.0, 1.5, mu2)
        + _one_loop_piece(mc2, -2.0, 1.5, mu2)
    )
    return tree + loop


def _nielsen_determinant_check() -> tuple[dict, dict]:
    m2, lam, g = 1.0, 0.20, 0.40
    v = math.sqrt(m2 / lam)
    mu2 = v**2
    xis = np.asarray([0.5, 1.0, 2.0, 3.0])
    phis = np.asarray([0.95 * v, v, 1.05 * v])
    values = np.asarray(
        [[_abelian_higgs_potential(float(phi), float(xi), m2, lam, g, mu2) for xi in xis] for phi in phis]
    )
    spreads = np.ptp(values, axis=1)
    extremum_scale = max(abs(float(np.mean(values[1]))), 1.0e-12)
    off_scale = max(abs(float(np.mean(values[[0, 2]]))), 1.0e-12)
    summary = {
        "model": "one-loop Abelian Higgs R_xi determinant",
        "tree_extremum_phi": v,
        "xi_values": xis.tolist(),
        "phi_values": phis.tolist(),
        "potential_values": values.tolist(),
        "absolute_xi_spread": spreads.tolist(),
        "extremum_relative_spread": float(spreads[1] / extremum_scale),
        "maximum_off_extremum_relative_spread": float(max(spreads[0], spreads[2]) / off_scale),
        "checks": {
            "unphysical_determinants_cancel_at_tree_extremum": spreads[1] < 1.0e-12,
            "off_extremum_gauge_dependence_is_resolved": max(spreads[0], spreads[2]) > 1.0e-6,
        },
        "scope": (
            "This is a real one-loop R_xi determinant/Nielsen check. It is not yet the requested momentum-dependent "
            "one-loop Higgs complex-pole calculation; that remains a gauge-pilot gate."
        ),
    }
    arrays = {"xi": xis, "phi": phis, "potential": values}
    return summary, arrays


def run(repo_root: Path, output_dir: Path) -> dict:
    array_path = (
        repo_root / "chronometric-emergence" / "original-info" /
        "prehpc_closure_research_package_v1_8" / "prehpc_closure_arrays_v1_8.npz"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    observable, obs_arrays = _elementary_vs_singlet(array_path)
    nielsen, nielsen_arrays = _nielsen_determinant_check()
    checks = {
        "elementary_peak_finite": math.isfinite(observable["elementary_peak_over_T"]),
        "singlet_peak_finite": math.isfinite(observable["singlet_peak_over_T"]),
        **nielsen["checks"],
    }
    report = {
        "title": "Executed observable and one-loop gauge checks",
        "elementary_vs_singlet": observable,
        "one_loop_nielsen": nielsen,
        "checks": checks,
        "all_pass": all(checks.values()),
        "remaining_gate": "momentum-dependent one-loop R_xi complex-pole test",
    }
    (output_dir / "observable_checks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    np.savez_compressed(output_dir / "observable_check_arrays.npz", **obs_arrays, **nielsen_arrays)

    fig, ax = plt.subplots(figsize=(7.4, 4.8))
    e = obs_arrays["elementary_rho"]
    s = obs_arrays["singlet_rho"]
    ax.plot(obs_arrays["elementary_omega"], e / max(np.max(e), 1.0e-30), label="elementary H")
    ax.plot(obs_arrays["singlet_omega"], s / max(np.max(s), 1.0e-30), label="singlet H-dagger-H")
    ax.set_xlim(0.0, 6.0)
    ax.set_xlabel("omega/T")
    ax.set_ylabel("normalised positive spectral density")
    ax.set_title("Executed elementary-versus-singlet spectral comparison")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "elementary_vs_singlet.png", dpi=220)
    plt.close(fig)
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    report = run(args.repo_root.resolve(), args.output_dir.resolve())
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["all_pass"] else 2)


if __name__ == "__main__":
    main()
