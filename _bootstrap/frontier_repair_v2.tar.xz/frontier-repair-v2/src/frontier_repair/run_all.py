from __future__ import annotations

from pathlib import Path
import argparse
import json

from . import environmental_ridge, nu0_fate, rg_audit, scalar_two_time, threepi_combinatorics
from . import kernel_uncertainty, lpm_repair, observable_checks, portability


def run(repo_root: Path, package_root: Path, expensive: bool = False) -> dict:
    results = package_root / "results"
    figures = package_root / "figures"
    docs = package_root / "docs"
    results.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    docs.mkdir(parents=True, exist_ok=True)

    reports: dict[str, dict] = {}
    reports["scalar_two_time"] = scalar_two_time.run_benchmark(
        output_dir=results / "scalar_two_time"
    )
    reports["threepi_combinatorics"] = threepi_combinatorics.run_audit(
        results / "threepi_combinatorics.json"
    )
    reports["nu0_fate"] = nu0_fate.run(
        results / "nu0_fate.json", results / "nu0_fate.csv"
    )
    reports["environmental_ridge"] = environmental_ridge.run(
        results / "environmental_ridge.json",
        results / "environmental_ridge.csv",
        figures / "environmental_ridge_profiles.png",
    )
    reports["rg_audit"] = rg_audit.run(
        results / "rg_audit.json", docs / "RETRACTION_V1_3_RG.md"
    )
    reports["lpm_repair"] = lpm_repair.run(
        repo_root,
        results / "lpm_repair.json",
        results / "lpm_repair.csv",
    )
    reports["kernel_uncertainty"] = kernel_uncertainty.run(
        repo_root, results / "kernel_uncertainty"
    )
    reports["observable_checks"] = observable_checks.run(
        repo_root, results / "observable_checks"
    )

    portability_report_path = results / "portability_audit.json"
    archive_report = portability.scan_tree(repo_root / "chronometric-emergence" / "original-info")
    repair_report = portability.scan_tree(package_root, code_only=True)
    reports["portability"] = {
        "archive": archive_report,
        "repair_package": repair_report,
        "repair_pass": repair_report["hardcoded_mnt_data_file_count"] == 0,
        "policy": "Historical original-info remains immutable; all new code is path portable.",
    }
    portability_report_path.write_text(json.dumps(reports["portability"], indent=2) + "\n", encoding="utf-8")

    if expensive:
        from . import v15_full_recompute
        reports["v15_full_recompute"] = v15_full_recompute.run(
            repo_root, results / "v15_full_recompute"
        )

    objective_checks = {
        "real_scalar_unit_tier": bool(reports["scalar_two_time"]["all_pass"]),
        "threepi_magnitudes_independently_verified": bool(reports["threepi_combinatorics"]["all_magnitudes_pass"]),
        "prompt_daughter_repair_rate_gate": bool(reports["nu0_fate"]["all_repair_gates_pass"]),
        "v14_recomputed": bool(reports["lpm_repair"]["all_pass"]),
        "kernel_uncertainty_and_domain_gate": bool(reports["kernel_uncertainty"]["all_pass"]),
        "observable_checks_executed": bool(reports["observable_checks"]["all_pass"]),
        "new_package_portable": bool(reports["portability"]["repair_pass"]),
        "v13_RG_overclaim_removed": reports["rg_audit"]["status"] == "RETRACT_V1_3_RG_COMPLETION",
        "compact_star_blocker_exposed": not reports["environmental_ridge"]["all_previous_no_screening_claims_survive"],
    }
    if expensive:
        objective_checks["v15_headline_fully_recomputed"] = bool(reports["v15_full_recompute"]["all_pass"])

    frontier = {
        "title": "Chronometric Emergence frontier-repair execution report",
        "objective_checks": objective_checks,
        "all_objective_repair_checks_pass": all(objective_checks.values()),
        "earned_status": (
            "REAL_SCALAR_UNIT_TIER_AND_EVIDENCE_REPAIR_COMPLETE"
            if all(objective_checks.values())
            else "REPAIR_INCOMPLETE"
        ),
        "not_earned": [
            "non-Abelian three-loop 3PI pilot",
            "publication-ready cosmological completion",
            "compact-star-safe phenomenology",
            "UV-quality completion",
        ],
        "reports": {
            name: str((results / name).relative_to(package_root)) if (results / name).exists() else name
            for name in reports
        },
    }
    (results / "frontier_repair_summary.json").write_text(json.dumps(frontier, indent=2) + "\n", encoding="utf-8")
    return frontier


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--expensive", action="store_true")
    args = parser.parse_args()
    report = run(args.repo_root.resolve(), args.package_root.resolve(), args.expensive)
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["all_objective_repair_checks_pass"] else 2)


if __name__ == "__main__":
    main()
