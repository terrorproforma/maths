# Chronometric Emergence frontier repair v2

**Author: Angus Muffatti**

This package executes the independent audit's repair programme rather than adding another decorative theory layer.

## What is genuinely new in this repair

- a real non-Markovian scalar two-time evolution with independent Hamiltonian and memory-kernel solvers;
- timestep and memory-window convergence, canonical-commutator, energy and FDT/KMS gates;
- independent graph-automorphism verification of all 11 v1.9 3PI symmetry-factor magnitudes;
- explicit failure of the original free-streaming prompt daughter and an exact-Z6 electroweak thermalisation repair;
- low-`f_a` Earth/Sun/white-dwarf/neutron-star environmental profiles;
- the `c6 < 2.64e-81` UV-quality bound;
- formal retraction of the hand-completed v1.3 RG claim;
- corrected v1.4 AMY effective-mass recomputation;
- mandatory full v1.5 high-resolution recomputation in release CI;
- v1.7-v1.8 off-shell model-discrepancy envelope and a no-extrapolation kernel contract;
- an executed elementary-versus-singlet spectral comparison;
- a real one-loop Abelian-Higgs R-xi determinant/Nielsen check;
- a sandbox-path-free package and portable legacy staging runner;
- an evidence taxonomy that separates identities, regressions, recomputation, convergence, external benchmarks and predictions.

## Honest status

The repair earns a **fallible scalar unit tier**, not a non-Abelian 3PI frontier run. The latter remains blocked by:

1. a momentum-dependent one-loop R-xi pole benchmark;
2. matrix-valued ghost/matter-ghost dynamics;
3. a real gauge 3PI evolution engine;
4. relativistic compact-star phenomenology;
5. a UV-quality Wilson-line/discrete-gauge completion.

## Run

```bash
python -m pip install -r requirements.txt
PYTHONPATH=src python -m frontier_repair.run_all \
  --repo-root ../.. \
  --package-root . \
  --expensive
pytest -q
```

The `--expensive` release mode recomputes the v1.5 n=10 quadrature and parameter scan rather than loading stored fixtures.
