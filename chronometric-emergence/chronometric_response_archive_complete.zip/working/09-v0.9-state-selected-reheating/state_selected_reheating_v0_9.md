---
title: "State-Selected Reheating in Exact Z6 Chronometry"
author: "Angus Muffatti"
version: "v0.9"
---

> Archive reconstruction from the surviving project ledger. Historical sandbox binaries were ephemeral; see RECOVERY_PROVENANCE.md.

## 33. Why hard asymmetric reheating is dangerous

The cyclic cancellation of lower vacuum harmonics relies on exact microscopic symmetry. A permanent sector-specific reheating coupling is a hard $Z_6$-breaking spurion and generically feeds lower harmonics back into the vacuum potential. The correct architecture is therefore

$$
\boxed{
\text{exact }Z_6\text{ action}
+\text{temporarily asymmetric state}.
}
$$

This distinction is strongly supported by later cyclic finite-density models [@Delaunay2026].

## 34. Orbit-symmetric reheaton and transient selector

Introduce two complete reheaton orbits $X_k,Y_k$ with oriented cyclic mixing. Light eigenstates have the schematic form

$$
R_k=\cos\theta\,X_k+\sin\theta\,Y_{k-1}.
$$

A selected population of $R_0$ decays into sectors 0 and 5. A complete selector orbit $Q_k$ has one-hot inflationary branches. On the $Q_0$ branch, all reheaton copies except $R_0$ are made kinematically inaccessible by an exactly $Z_6$-invariant mass pattern.

The key chronology is

$$
\Gamma_{\phi\rightarrow R_0R_0}
\gg\Gamma_Q\gg\Gamma_R.
$$

The inflaton first produces the labelled state. The selector returns to the symmetric origin before the reheaton decays. The asymmetry survives in occupation numbers, not in late-time masses or couplings.

At the first homogeneous level, a branching ratio $\Gamma_5/\Gamma_0=1/256$ gives $T_5/T_0=1/4$. The nonlinear cascade later corrects the exact mixing required to achieve that final temperature ratio.

## 35. Perturbations and isocurvature

For fixed branching fractions,

$$
\rho_i=B_i\rho_R,
$$

and radiation curvature perturbations satisfy

$$
\zeta_i=\zeta_R+\frac14\delta\ln B_i.
$$

If the branching fractions are fixed constants,

$$
\delta B_0=\delta B_5=0,
$$

so

$$
S_{50}=3(\zeta_5-\zeta_0)=0.
$$

The extra radiation is adiabatic at linear order. This would fail if the mixing angle were a light modulus, because its fluctuation would be amplified by the small adjacent branching fraction. The benchmark keeps the mixing and selector sectors heavy during inflation.

The initial chronometric phase fluctuation

$$
\delta x_{\mathrm{reh}}=\frac{H_*}{2\pi f_a}
$$

is strongly damped by threshold, QCD, and baryon focusing. The staged calculation found a transfer magnitude of about $10^{-6}$ by recombination and a residual QCD-lock fluctuation near $10^{-23}$. This remains a reduced perturbation calculation, not a full Einstein-Boltzmann likelihood.
