---
title: "Crossed-Null Chronometry: Priority Audit and Dynamical Viability Test"
author: "Angus Muffatti"
version: "v0.2"
---

> Archive reconstruction from the surviving project ledger. Historical sandbox binaries were ephemeral; see RECOVERY_PROVENANCE.md.

## 7. Failure of the exact-null action

The first complete constrained action was

$$
S_0=\int d^4x\sqrt{-g}\left[
\frac{M_{\mathrm{P}}^2}{2}R
+A_+Y_++A_-Y_-
-\frac\kappa2(C-\sigma^2)^2
-\frac12(\nabla\sigma)^2
-V(\sigma)
\right],
$$

where

$$
Y_\pm=(\nabla\phi_\pm)^2,
\qquad
C=-\frac12\nabla\phi_+\cdot\nabla\phi_-.
$$

Around

$$
\bar\phi_+=m(t-x),
\qquad
\bar\phi_-=m(t+x),
$$

the linearised constraints are

$$
(\partial_t+\partial_x)\pi_+=0,
\qquad
(\partial_t-\partial_x)\pi_-=0.
$$

Define

$$
s=\frac{\pi_++\pi_-}{\sqrt2},
\qquad
r=\frac{\pi_+-\pi_-}{\sqrt2}.
$$

The lock fluctuation is

$$
\delta C=\frac{m}{\sqrt2}(\dot s-\partial_x r).
$$

Neither the linear constraints nor the quadratic lock contains $\partial_y$ or $\partial_z$. Transverse gradients first enter nonlinearly through terms such as $(\nabla\pi_\pm)^2$. The quadratic principal symbol is therefore rank deficient for generic transverse perturbations. Nonlinear terms control directions with no quadratic restoring operator.

$$
\boxed{
\text{Verdict: the exact-null constrained action is not a controlled ordinary }3+1\text{D EFT.}
}
$$

The positive homogeneous Hessian did not detect this because it tested only algebraic order-parameter fluctuations.

## 8. Healthy soft-null repair

The minimal repair makes the phases ordinary propagating compact fields and treats crossed nullity as a background state:

$$
\boxed{
\mathcal L_{\mathrm{EFT}}
=-\frac F2(Y_++Y_-)
+\frac\kappa2(C-m^2)^2.
}
$$

Define

$$
a=\frac{\kappa m^2}{2},
\qquad
\epsilon=\frac aF.
$$

The quadratic Lagrangian in $s,r$ is

$$
\begin{aligned}
\mathcal L^{(2)}={}&
\frac12(F+a)\dot s^2
+\frac12F\dot r^2
-a\dot s\,\partial_xr\\
&-\frac F2[(\nabla s)^2+(\nabla r)^2]
+\frac a2(\partial_xr)^2.
\end{aligned}
$$

The Hamiltonian is positive when

$$
\boxed{F>0,\qquad0<a<F,}
$$

or $0<\epsilon<1$. The principal polynomial factorises:

$$
F(\omega^2-k^2)
\left[(F+a)\omega^2-Fk^2+ak_x^2\right]=0.
$$

The modes are

$$
\omega_1^2=k^2,
$$

$$
\omega_2^2=\frac{Fk^2-ak_x^2}{F+a}.
$$

Writing $k_x=k\cos\theta$,

$$
\boxed{
c_2^2(\theta)=\frac{1-\epsilon\cos^2\theta}{1+\epsilon}.
}
$$

For $0<\epsilon<1$, the second mode is real, positive, and subluminal for every direction. The model belongs to the established two-superfluid/entrainment class rather than defining a new species of matter [@Superfluid2015].

### Local mediator completion

Introduce a healthy massive scalar $H$:

$$
\mathcal L_{\mathrm{med}}
=-\frac F2(Y_++Y_-)
-\frac12(\nabla H)^2
-\frac12M^2H^2
+g_HH(C-m^2).
$$

Integrating it out below $M$ gives

$$
\Delta\mathcal L
=\frac{g_H^2}{2}(C-m^2)\frac1{M^2-\Box}(C-m^2),
$$

and therefore

$$
\boxed{\kappa=\frac{g_H^2}{M^2}>0.}
$$

The sign is compatible with exchange of a positive-residue massive state and with standard positivity reasoning [@Adams2006].

### Model-specific tree-level sum rules

Parallel and perpendicular speeds satisfy

$$
c_\parallel^2=\frac{1-\epsilon}{1+\epsilon},
\qquad
c_\perp^2=\frac1{1+\epsilon},
$$

hence

$$
\boxed{c_\parallel^2=2c_\perp^2-1.}
$$

For the minimal one-mediator completion, the $k^4$ dispersion coefficients also obey

$$
\boxed{\alpha_\parallel=4\alpha_\perp.}
$$

These are not universal laws of two-fluid physics. They are consistency relations of the minimal model and will be perturbed by additional operators, resonances, and loops.

## 9. Gravity coupling and circularity

The direct substitution

$$
g^{\mathrm{physical}}_{\mu\nu}=Cg_{\mu\nu}
$$

is singular and mimetic. It does not evade the noninvertibility or extra-mode problem. A regular alternative introduces a Weyl compensator $\chi$:

$$
g_{\mu\nu}\rightarrow\Omega^2g_{\mu\nu},
\qquad
\chi\rightarrow\Omega^{-1}\chi,
$$

$$
\widehat g_{\mu\nu}
=\frac{\chi^2}{6M_{\mathrm{P}}^2}g_{\mu\nu}.
$$

A representative action is

$$
\begin{aligned}
S_W=\int\sqrt{-g}\Big[&
\frac{\chi^2}{12}R
+\frac12(\nabla\chi)^2
-\frac{f^2\chi^2}{2}(Y_++Y_-)\\
&+\frac\kappa2(C-\zeta\chi^2)^2
\Big].
\end{aligned}
$$

On the locking surface, the phase state calibrates the same invariant metric used by gravity. This is a regular EFT representation of chronometric calibration. It does not derive Einstein dynamics from null phases. The conformal manifold and gravitational action remain inputs.
